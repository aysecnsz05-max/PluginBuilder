/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.block.data.BlockData
 */
package ai.idealistic.spartan.abstraction.world;

import ai.idealistic.spartan.utils.minecraft.world.BlockUtils;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;

public class ServerBlock {
    private final Object block;

    ServerBlock(Object block) {
    }

    public boolean dataLoaded() {
        return this.block != null;
    }

    public boolean isMaterial() {
        return this.block instanceof Material;
    }

    public boolean isBlock() {
        return this.block instanceof Block;
    }

    public boolean isBlockData() {
        return BlockUtils.blockDataExists && this.block instanceof BlockData;
    }

    public Material getType() {
        if (this.block instanceof Block) {
            return ((Block)this.block).getType();
        }
        if (this.block instanceof Material) {
            return (Material)this.block;
        }
        if (BlockUtils.blockDataExists && this.block instanceof BlockData) {
            return ((BlockData)this.block).getMaterial();
        }
        return Material.AIR;
    }

    public Material getTypeOrNull() {
        if (this.block instanceof Block) {
            return ((Block)this.block).getType();
        }
        if (this.block instanceof Material) {
            return (Material)this.block;
        }
        if (BlockUtils.blockDataExists && this.block instanceof BlockData) {
            return ((BlockData)this.block).getMaterial();
        }
        return null;
    }

    public boolean isWaterLogged() {
        return this.block instanceof Block ? BlockUtils.isWaterLogged(Blockthis.block) : BlockUtils.blockDataExists && this.block instanceof BlockData && BlockUtils.isWaterLogged(BlockDatathis.block);
    }

    public boolean isLiquidOrWaterLogged(boolean lava) {
        return this.block instanceof Block ? BlockUtils.isLiquidOrWaterLogged(Blockthis.block, lava) : (this.block instanceof Material ? BlockUtils.isLiquid(Materialthis.block) : BlockUtils.blockDataExists && this.block instanceof BlockData && BlockUtils.isLiquidOrWaterLogged(BlockDatathis.block, lava));
    }

    public boolean isLiquid(Material target) {
        Material material;
        if (this.block instanceof Block) {
            Block block = (Block)this.block;
            return BlockUtils.isLiquid(block) && block.getType() == target;
        }
        if (this.block instanceof Material) {
            material = (Material)this.block;
        } else if (BlockUtils.blockDataExists && this.block instanceof BlockData) {
            material = ((BlockData)this.block).getMaterial();
        } else {
            return false;
        }
        return BlockUtils.isLiquid(material) && material == target;
    }
}

