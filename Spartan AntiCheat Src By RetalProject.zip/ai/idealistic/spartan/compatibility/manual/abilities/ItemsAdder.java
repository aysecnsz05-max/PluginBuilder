/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  dev.lone.itemsadder.api.CustomBlock
 *  dev.lone.itemsadder.api.CustomEntity
 *  dev.lone.itemsadder.api.CustomStack
 *  dev.lone.itemsadder.api.Events.CustomBlockBreakEvent
 *  dev.lone.itemsadder.api.Events.CustomBlockPlaceEvent
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Entity
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package ai.idealistic.spartan.compatibility.manual.abilities;

import ai.idealistic.spartan.abstraction.check.CheckEnums;
import ai.idealistic.spartan.abstraction.protocol.PlayerProtocol;
import ai.idealistic.spartan.compatibility.Compatibility;
import ai.idealistic.spartan.functionality.server.Config;
import ai.idealistic.spartan.functionality.server.MultiVersion;
import ai.idealistic.spartan.functionality.server.PluginBase;
import dev.lone.itemsadder.api.CustomBlock;
import dev.lone.itemsadder.api.CustomEntity;
import dev.lone.itemsadder.api.CustomStack;
import dev.lone.itemsadder.api.Events.CustomBlockBreakEvent;
import dev.lone.itemsadder.api.Events.CustomBlockPlaceEvent;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class ItemsAdder
implements Listener {
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void Place(CustomBlockPlaceEvent e) {
        Config.compatibility.evadeFalsePositives(PluginBase.getProtocol(e.getPlayer()), Compatibility.CompatibilityType.GRAPPLING_HOOK, CheckEnums.HackCategoryType.WORLD, 20);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void Break(CustomBlockBreakEvent e) {
        Config.compatibility.evadeFalsePositives(PluginBase.getProtocol(e.getPlayer()), Compatibility.CompatibilityType.GRAPPLING_HOOK, CheckEnums.HackCategoryType.WORLD, 20);
    }

    public static boolean is(PlayerProtocol protocol) {
        if (Compatibility.CompatibilityType.ITEMS_ADDER.isFunctional()) {
            PlayerInventory inventory = protocol.getInventory();
            for (ItemStack armor : inventory.getArmorContents()) {
                if (armor == null || !ItemsAdder.is(armor)) continue;
                return true;
            }
            return ItemsAdder.is(inventory.getItemInHand()) || MultiVersion.isOrGreater(MultiVersion.MCVersion.V1_9) && ItemsAdder.is(inventory.getItemInOffHand());
        }
        return false;
    }

    public static boolean is(Block block) {
        return Compatibility.CompatibilityType.ITEMS_ADDER.isFunctional() && CustomBlock.byAlreadyPlaced(Blockblock) != null;
    }

    private static boolean is(ItemStack itemStack) {
        CustomStack customStack;
        if (Compatibility.CompatibilityType.ITEMS_ADDER.isFunctional() && (customStack = CustomStack.byItemStack(ItemStackitemStack)) != null) {
            return CustomStack.isInRegistry((String)customStack.getNamespacedID());
        }
        return false;
    }

    public static boolean is(Entity entity) {
        return Compatibility.CompatibilityType.ITEMS_ADDER.isFunctional() && CustomEntity.isCustomEntity(Entityentity);
    }
}

