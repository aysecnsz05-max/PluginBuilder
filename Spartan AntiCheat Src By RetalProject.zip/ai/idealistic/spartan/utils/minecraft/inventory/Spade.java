/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.World$Environment
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.util.NumberConversions
 */
package ai.idealistic.spartan.utils.minecraft.inventory;

import ai.idealistic.spartan.abstraction.protocol.ExtendedPotionEffect;
import ai.idealistic.spartan.abstraction.protocol.PlayerProtocol;
import ai.idealistic.spartan.abstraction.world.ServerBlock;
import ai.idealistic.spartan.abstraction.world.ServerLocation;
import ai.idealistic.spartan.functionality.server.MultiVersion;
import ai.idealistic.spartan.utils.minecraft.entity.PotionEffectUtils;
import ai.idealistic.spartan.utils.minecraft.inventory.Arrow;
import ai.idealistic.spartan.utils.minecraft.world.BlockUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.util.NumberConversions;

public class Spade {
    private static final Map<String, Material> alternative = new LinkedHashMap<String, Material>2;
    private static final Map<Material, Double> baseMultiplier = new LinkedHashMap<Material, Double>2;
    private static final double specialMultiplier = 1.5;

    public static Material get(String s) {
        return alternative.get(s.toLowerCase());
    }

    public static Material correct(String recent, String older) {
        return Material.getMaterial((String)(MultiVersion.isOrGreater(MultiVersion.MCVersion.V1_13) ? recent.toUpperCase() : older.toUpperCase()));
    }

    public static long getBlockBreakTime(PlayerProtocol protocol, ItemStack itemStack, Material blockType) {
        if (MultiVersion.isOrGreater(MultiVersion.MCVersion.V1_13) && blockType.isBlock()) {
            boolean water;
            ExtendedPotionEffect miningFatigueEffect;
            double multiplier = baseMultiplier.getOrDefault(itemStack.getType(), 1.0);
            boolean canHarvest = true;
            if (multiplier == 1.5) {
                if (itemStack.getType() == Material.SHEARS) {
                    if (BlockUtils.areWebs(blockType) || BlockUtils.areLeaves(blockType)) {
                        multiplier = 15.0;
                    } else if (BlockUtils.areWools(blockType)) {
                        multiplier = 5.0;
                    }
                } else if (BlockUtils.areWebs(blockType)) {
                    multiplier = 15.0;
                }
            }
            if (!canHarvest) {
                multiplier = 1.0;
            } else {
                int enchantmentLevel = itemStack.getEnchantmentLevel(Arrow.DIG_SPEED);
                if (enchantmentLevel > 0) {
                    multiplier += Math.pow(enchantmentLevel, 2.0) + 1.0;
                }
            }
            ExtendedPotionEffect hasteEffect = protocol.getPotionEffect(PotionEffectUtils.FAST_DIGGING, 0L);
            if (hasteEffect != null && hasteEffect.isActive()) {
                multiplier *= 0.2 * doublehasteEffect.bukkitEffect.getAmplifier() + 1.0;
            }
            if ((miningFatigueEffect = protocol.getPotionEffect(PotionEffectUtils.SLOW_DIGGING, 0L)) != null && miningFatigueEffect.isActive()) {
                multiplier *= Math.pow(miningFatigueEffect.bukkitEffect.getAmplifier(), 0.3);
            }
            if (protocol.isSwimming()) {
                water = true;
            } else {
                ServerBlock block = new ServerLocation(protocol.getLocation()).add(0.0, protocol.getEyeHeight(), 0.0).getBlock(protocol);
                water = block.isWaterLogged() || block.getType() == Spade.get("water");
            }
            if (water) {
                boolean aquaInfinity = false;
                if (itemStack.getEnchantmentLevel(Arrow.WATER_WORKER) > 0) {
                    aquaInfinity = true;
                } else {
                    PlayerInventory inventory = protocol.getInventory();
                    ArrayList<ItemStack> items = new ArrayList<ItemStack>5;
                    items.addAll(Arrays.asList(inventory.getArmorContents()));
                    items.add(inventory.getItemInHand());
                    for (ItemStack item : items) {
                        if (item == null || item.getEnchantmentLevel(Arrow.WATER_WORKER) <= 0) continue;
                        aquaInfinity = true;
                        break;
                    }
                }
                if (!aquaInfinity) {
                    multiplier /= 5.0;
                }
            }
            if (!protocol.isOnGround()) {
                multiplier /= 5.0;
            }
            double damage = multiplier / doubleblockType.getHardness();
            damage = canHarvest ? (damage /= 30.0) : (damage /= 100.0);
            if (damage > 1.0) {
                return 0L;
            }
            double ticks = Math.ceil(1.0 / damage);
            return NumberConversions.round(double(ticks * 50.0));
        }
        return -1L;
    }

    public static Material findMaterial(String string) {
        for (Material material : Material.values()) {
            if (!material.toString().equals(string)) continue;
            return material;
        }
        return null;
    }

    public static World.Environment findEnvironment(String string) {
        for (World.Environment environment : World.Environment.values()) {
            if (!string.toString().equals(string)) continue;
            return environment;
        }
        return null;
    }

    static {
        if (MultiVersion.isOrGreater(MultiVersion.MCVersion.V1_13)) {
            alternative.put("water", Material.WATER);
            alternative.put("lava", Material.LAVA);
            alternative.put("web", Material.COBWEB);
            alternative.put("gold_axe", Material.GOLDEN_AXE);
            alternative.put("wood_axe", Material.WOODEN_AXE);
            alternative.put("gold_pickaxe", Material.GOLDEN_PICKAXE);
            alternative.put("wood_pickaxe", Material.WOODEN_PICKAXE);
            alternative.put("gold_sword", Material.GOLDEN_SWORD);
            alternative.put("wood_sword", Material.WOODEN_SWORD);
            alternative.put("watch", Material.CLOCK);
            alternative.put("exp_bottle", Material.EXPERIENCE_BOTTLE);
            alternative.put("redstone_comparator", Material.COMPARATOR);
            alternative.put("cake", Material.CAKE);
            alternative.put("diamond_spade", Material.DIAMOND_HOE);
            alternative.put("iron_spade", Material.IRON_HOE);
            alternative.put("gold_spade", Material.GOLDEN_HOE);
            alternative.put("stone_spade", Material.STONE_HOE);
            alternative.put("wood_spade", Material.WOODEN_HOE);
            alternative.put("beetroot_block", Material.BEETROOT);
            alternative.put("magma", Material.MAGMA_BLOCK);
            alternative.put("firework", Material.FIREWORK_ROCKET);
            alternative.put("nether_portal", Material.NETHER_PORTAL);
            alternative.put("cobblestone_wall", Material.COBBLESTONE_WALL);
            alternative.put("end_portal_frame", Material.END_PORTAL_FRAME);
            alternative.put("iron_bars", Material.IRON_BARS);
            alternative.put("enchanting_table", Material.ENCHANTING_TABLE);
            alternative.put("piston_extension", Material.PISTON_HEAD);
            alternative.put("piston_moving", Material.MOVING_PISTON);
            alternative.put("piston", Material.PISTON);
            alternative.put("sticky_piston", Material.STICKY_PISTON);
            alternative.put("lily_pad", Material.LILY_PAD);
            alternative.put("repeater_on", Material.REPEATER);
            alternative.put("repeater_off", Material.REPEATER);
            alternative.put("comparator_on", Material.COMPARATOR);
            alternative.put("comparator_off", Material.COMPARATOR);
            alternative.put("soil", Material.FARMLAND);
            alternative.put("gold_boots", Material.GOLDEN_BOOTS);
            alternative.put("grass_block", Material.GRASS_BLOCK);
            alternative.put("diamond_shovel", Material.DIAMOND_SHOVEL);
            alternative.put("gold_shovel", Material.GOLDEN_SHOVEL);
            alternative.put("iron_shovel", Material.IRON_SHOVEL);
            alternative.put("stone_shovel", Material.STONE_SHOVEL);
            alternative.put("wood_shovel", Material.WOODEN_SHOVEL);
            alternative.put("redstone_torch", Material.REDSTONE_TORCH);
            alternative.put("daylight_detector_1", Material.DAYLIGHT_DETECTOR);
            alternative.put("daylight_detector_2", Material.DAYLIGHT_DETECTOR);
            alternative.put("crafting_table", Material.CRAFTING_TABLE);
            alternative.put("furnace", Material.FURNACE);
            alternative.put("snowball", Material.SNOWBALL);
            alternative.put("fireball", Material.FIRE_CHARGE);
            alternative.put("lead", Material.LEAD);
            alternative.put("carrot_on_a_stick", Material.CARROT_ON_A_STICK);
        } else {
            alternative.put("water", Material.getMaterial("STATIONARY_WATER"));
            alternative.put("lava", Material.getMaterial("STATIONARY_LAVA"));
            alternative.put("web", Material.getMaterial("WEB"));
            alternative.put("gold_axe", Material.getMaterial("GOLD_AXE"));
            alternative.put("wood_axe", Material.getMaterial("WOOD_AXE"));
            alternative.put("gold_pickaxe", Material.getMaterial("GOLD_PICKAXE"));
            alternative.put("wood_pickaxe", Material.getMaterial("WOOD_PICKAXE"));
            alternative.put("gold_sword", Material.getMaterial("GOLD_SWORD"));
            alternative.put("wood_sword", Material.getMaterial("WOOD_SWORD"));
            alternative.put("watch", Material.getMaterial("WATCH"));
            alternative.put("exp_bottle", Material.getMaterial("EXP_BOTTLE"));
            alternative.put("redstone_comparator", Material.getMaterial("REDSTONE_COMPARATOR"));
            alternative.put("cake", Material.getMaterial("CAKE_BLOCK"));
            alternative.put("diamond_spade", Material.getMaterial("DIAMOND_SPADE"));
            alternative.put("iron_spade", Material.getMaterial("IRON_SPADE"));
            alternative.put("gold_spade", Material.getMaterial("GOLD_SPADE"));
            alternative.put("stone_spade", Material.getMaterial("STONE_SPADE"));
            alternative.put("wood_spade", Material.getMaterial("WOOD_SPADE"));
            alternative.put("beetroot_block", Material.getMaterial("BEETROOT_BLOCK"));
            alternative.put("magma", Material.getMaterial("MAGMA"));
            alternative.put("firework", Material.getMaterial("FIREWORK"));
            alternative.put("nether_portal", Material.getMaterial("PORTAL"));
            alternative.put("cobblestone_wall", Material.getMaterial("COBBLE_WALL"));
            alternative.put("end_portal_frame", Material.getMaterial("ENDER_PORTAL_FRAME"));
            alternative.put("iron_bars", Material.getMaterial("IRON_FENCE"));
            alternative.put("enchanting_table", Material.getMaterial("ENCHANTMENT_TABLE"));
            alternative.put("piston_extension", Material.getMaterial("PISTON_EXTENSION"));
            alternative.put("piston_moving", Material.getMaterial("PISTON_MOVING_PIECE"));
            alternative.put("piston", Material.getMaterial("PISTON_BASE"));
            alternative.put("sticky_piston", Material.getMaterial("PISTON_STICKY_BASE"));
            alternative.put("lily_pad", Material.getMaterial("WATER_LILY"));
            alternative.put("repeater_on", Material.getMaterial("DIODE_BLOCK_ON"));
            alternative.put("repeater_off", Material.getMaterial("DIODE_BLOCK_OFF"));
            alternative.put("comparator_on", Material.getMaterial("REDSTONE_COMPARATOR_ON"));
            alternative.put("comparator_off", Material.getMaterial("REDSTONE_COMPARATOR_OFF"));
            alternative.put("soil", Material.getMaterial("SOIL"));
            alternative.put("gold_boots", Material.getMaterial("GOLD_BOOTS"));
            alternative.put("grass_block", Material.getMaterial("GRASS"));
            alternative.put("diamond_shovel", Material.getMaterial("DIAMOND_SPADE"));
            alternative.put("gold_shovel", Material.getMaterial("GOLD_SPADE"));
            alternative.put("iron_shovel", Material.getMaterial("IRON_SPADE"));
            alternative.put("stone_shovel", Material.getMaterial("STONE_SPADE"));
            alternative.put("wood_shovel", Material.getMaterial("WOOD_SPADE"));
            alternative.put("redstone_torch", Material.getMaterial("REDSTONE_TORCH_ON"));
            alternative.put("daylight_detector_1", Material.getMaterial("DAYLIGHT_DETECTOR"));
            alternative.put("daylight_detector_2", Material.getMaterial("DAYLIGHT_DETECTOR_INVERTED"));
            alternative.put("crafting_table", Material.getMaterial("WORKBENCH"));
            alternative.put("furnace", Material.getMaterial("BURNING_FURNACE"));
            alternative.put("snowball", Material.getMaterial("SNOW_BALL"));
            alternative.put("fireball", Material.getMaterial("FIREBALL"));
            alternative.put("lead", Material.getMaterial("LEASH"));
            alternative.put("carrot_on_a_stick", Material.getMaterial("CARROT_STICK"));
        }
for (Material m : Material.values()) {
            String s = m.toString();
            if (BlockUtils.endsWith(s, "_SWORD")) {
                baseMultiplier.put(m, 1.5);
                continue;
            }
            switch (s) {
                case "DIAMOND_PICKAXE":
                case "DIAMOND_AXE":
                case "DIAMOND_HOE":
                case "DIAMOND_SHOVEL":
                case "DIAMOND_SPADE": {
                    baseMultiplier.put(m, 8.0);
                    continue block49;
                }
                case "NETHERITE_PICKAXE":
                case "NETHERITE_AXE":
                case "NETHERITE_HOE":
                case "NETHERITE_SHOVEL": {
                    baseMultiplier.put(m, 9.0);
                    continue block49;
                }
                case "STONE_PICKAXE":
                case "STONE_AXE":
                case "STONE_HOE":
                case "STONE_SHOVEL":
                case "STONE_SPADE": {
                    baseMultiplier.put(m, 4.0);
                    continue block49;
                }
                case "IRON_PICKAXE":
                case "IRON_AXE":
                case "IRON_HOE":
                case "IRON_SHOVEL":
                case "IRON_SPADE": {
                    baseMultiplier.put(m, 6.0);
                    continue block49;
                }
                case "WOODEN_PICKAXE":
                case "WOOD_PICKAXE":
                case "WOODEN_AXE":
                case "WOOD_AXE":
                case "WOODEN_HOE":
                case "WOOD_HOE":
                case "WOODEN_SHOVEL":
                case "WOOD_SHOVEL":
                case "WOOD_SPADE": {
                    baseMultiplier.put(m, 2.0);
                    continue block49;
                }
                case "GOLDEN_PICKAXE":
                case "GOLD_PICKAXE":
                case "GOLDEN_AXE":
                case "GOLD_AXE":
                case "GOLDEN_HOE":
                case "GOLD_HOE":
                case "GOLDEN_SHOVEL":
                case "GOLD_SHOVEL":
                case "GOLD_SPADE": {
                    baseMultiplier.put(m, 12.0);
                    continue block49;
                }
                case "SHEARS": {
                    baseMultiplier.put(m, 1.5);
                }
            }
        }
    }
}

