/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  lombok.Generated
 */
package kireiko.dev.millennium.math;

import ai.idealistic.spartan.abstraction.protocol.PlayerProtocol;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kireiko.dev.millennium.math.MathCollection;
import lombok.Generated;

public final class OtherSensitivityProcessor {
    private static final double[] SENSITIVITY_MCP_VALUES = new double[]{0.0, 0.00704225, 0.01408451, 0.01760563, 0.02112676, 0.02816901, 0.02816902, 0.03521127, 0.04225352, 0.04929578, 0.04929577, 0.05633803, 0.06338028, 0.06690141, 0.07042254, 0.07746479, 0.08450704, 0.08802817, 0.09154929, 0.09859155, 0.10211267, 0.1056338, 0.11267605, 0.11971831, 0.12323943, 0.12676056, 0.13380282, 0.13732395, 0.14084508, 0.14788732, 0.15492958, 0.15845071, 0.16197184, 0.16901408, 0.17253521, 0.17605634, 0.18309858, 0.18661971, 0.19014084, 0.1971831, 0.20422535, 0.20774647, 0.2112676, 0.21830986, 0.22183098, 0.22535211, 0.23239437, 0.23943663, 0.24295775, 0.24647887, 0.2535211, 0.25704224, 0.26056337, 0.26760563, 0.2746479, 0.27816902, 0.28169015, 0.28873238, 0.29225351, 0.29577464, 0.3028169, 0.30985916, 0.31338029, 0.31690142, 0.32394367, 0.32746478, 0.3309859, 0.33802816, 0.34507042, 0.34859155, 0.35211268, 0.35915494, 0.36267605, 0.36619717, 0.37323943, 0.37676056, 0.3802817, 0.38732395, 0.3943662, 0.39788733, 0.40140846, 0.4084507, 0.41197183, 0.41549295, 0.4225352, 0.42957747, 0.4330986, 0.43661973, 0.44366196, 0.44718309, 0.45070422, 0.45774648, 0.46478873, 0.46830986, 0.471831, 0.47887325, 0.48239436, 0.48591548, 0.49295774, 0.5, 0.5, 0.5070422, 0.5140845, 0.51760563, 0.52112675, 0.52816904, 0.53169015, 0.53521127, 0.5422535, 0.5492958, 0.5528169, 0.556338, 0.5633803, 0.56690142, 0.57042253, 0.57746476, 0.58450705, 0.58802818, 0.5915493, 0.59859157, 0.60211269, 0.6056338, 0.6126761, 0.6197183, 0.62323942, 0.62676054, 0.63380283, 0.63732395, 0.64084506, 0.64788735, 0.6549296, 0.6584507, 0.6619718, 0.6690141, 0.6725352, 0.6760563, 0.6830986, 0.68661972, 0.69014084, 0.6971831, 0.70422536, 0.70774648, 0.7112676, 0.7183099, 0.7253521, 0.7253521, 0.73239434, 0.7394366, 0.74295773, 0.74647886, 0.75352114, 0.75704227, 0.7605634, 0.76760566, 0.7746479, 0.778169, 0.7816901, 0.7887324, 0.79225352, 0.79577464, 0.8028169, 0.80985916, 0.81338028, 0.8169014, 0.8239437, 0.8274648, 0.8309859, 0.8380282, 0.8415493, 0.8450704, 0.85211265, 0.85915494, 0.86267605, 0.86619717, 0.87323946, 0.87676058, 0.8802817, 0.8873239, 0.8943662, 0.89788731, 0.90140843, 0.9084507, 0.91197182, 0.91549295, 0.92253524, 0.92957747, 0.93309858, 0.9366197, 0.943662, 0.9471831, 0.9507042, 0.9577465, 0.96478873, 0.96830985, 0.97183096, 0.97887325, 0.98239437, 0.9859155, 0.9929578, 1.0, 1.0};
    private final List<Integer> sensitivitySamples = new ArrayList<Integer>();
    private final List<Integer> sensitivityStrictSamples = new ArrayList<Integer>();
    private final PlayerProtocol playerProfile;
    public double totalSensitivity = 0.0;
    public int totalSensitivityClient = 0;
    private float deltaPitch = 0.0f;
    private float lastDeltaPitch = 0.0f;
    private double finalSensitivity;
    private int sensitivity;
    private int lastStrictSensitivity = 0;

    public OtherSensitivityProcessor(PlayerProtocol playerProfile) {
    }

    public static double getGcd(double x, double y) {
        if (Math.abs(b) < 0.001 || a == b) {
            return a;
        }
        if (a < b) {
            return OtherSensitivityProcessor.getGcd(b, a);
        }
        return OtherSensitivityProcessor.getGcd(b, a - Math.floor(a / b) * b);
    }

    public static int getMode(Collection<? extends Number> array) {
        int mode = (Integer)array.toArray()[0];
        int maxCount = 0;
        for (Number number : array) {
            int count = 1;
            for (Number number2 : array) {
                if (number2.equals(number)) {
                    ++count;
                }
                if (count <= maxCount) continue;
                mode = (Integer)number;
                maxCount = count;
            }
        }
        return mode;
    }

    public void processSensitivity() {
        double finalSensitivity;
        if (doubleMath.abs(this.deltaPitch) < 0.31) {
            for (i < 200; ++i) {
                double gcdValue = MathCollection.getGCDValue(SENSITIVITY_MCP_VALUES[i]);
                double diff = Math.abs(gcdValue - doubleMath.abs(this.deltaPitch));
                if (!(diff < 0.001)) continue;
                this.sensitivityStrictSamples.add(i);
                if (this.sensitivityStrictSamples.size() < 10) break;
                int finalSens = (int)MathCollection.getMin(this.sensitivityStrictSamples);
                if (finalSens == this.lastStrictSensitivity) {
                    this.playerProfile.getSensitivity().clear();
                    for (r < 5; ++r) {
                        this.playerProfile.getSensitivity().add(finalSens);
                    }
                } else {
                    this.playerProfile.getSensitivity().add(finalSens);
                }
                this.sensitivityStrictSamples.clear();
                this.lastStrictSensitivity = finalSens;
                break;
            }
        }
        float gcd = (float)OtherSensitivityProcessor.getGcd(this.deltaPitch, this.lastDeltaPitch);
        double sensitivityModifier = Math.cbrt(0.8333 * doublegcd);
        double sensitivityStepTwo = 1.666 * sensitivityModifier.3333;
        this.finalSensitivity = finalSensitivity = sensitivityStepTwo * 200.0;
        this.sensitivitySamples.add((int)finalSensitivity);
        if (this.sensitivitySamples.size() >= 40) {
            this.sensitivity = OtherSensitivityProcessor.getMode(this.sensitivitySamples);
            if (this.hasValidSensitivity()) {
                this.totalSensitivityClient = this.sensitivity;
                this.totalSensitivity = SENSITIVITY_MCP_VALUES[this.sensitivity];
                this.playerProfile.getSensitivity().add(this.totalSensitivityClient);
            }
            this.sensitivitySamples.clear();
        }
    }

    public double getWrappedSensitivity() {
        return this.totalSensitivity == 0.0 ? SENSITIVITY_MCP_VALUES[100] : this.totalSensitivity;
    }

    private int calculateMode(List<Integer> samples) {
        HashMap<Integer, Integer> frequencyMap = new HashMap<Integer, Integer>();
        for (int sample : samples) {
            frequencyMap.put(sample, frequencyMap.getOrDefault(sample, 0) + 1);
        }
        return frequencyMap.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(0);
    }

    private boolean hasValidSensitivity() {
        return this.sensitivity >= 0 && this.sensitivity <= 200;
    }

    @Generated
    public static double[] getSENSITIVITY_MCP_VALUES() {
        return SENSITIVITY_MCP_VALUES;
    }

    @Generated
    public void setDeltaPitch(float deltaPitch) {
    }

    @Generated
    public void setLastDeltaPitch(float lastDeltaPitch) {
    }

    @Generated
    public float getLastDeltaPitch() {
        return this.lastDeltaPitch;
    }

    @Generated
    public double getFinalSensitivity() {
        return this.finalSensitivity;
    }

    @Generated
    public int getSensitivity() {
        return this.sensitivity;
    }
}

